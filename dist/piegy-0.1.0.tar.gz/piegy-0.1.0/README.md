# peigy
Payoff-Driven Stochastic Spatial Model for Evolutionary Game Theory
